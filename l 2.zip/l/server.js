const express = require('express');
const app = express();

app.listen(4000, function(){
    console.log('server in ascolto su porta 4000');
})
app.use(express.static('public'));
